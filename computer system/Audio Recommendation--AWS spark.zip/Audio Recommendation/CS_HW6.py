
# coding: utf-8
"""
@author: 
     Sha Yu Han (sy2739)
     Chengzhang Xu (cx2188)
     Yiwen Zhang (yz3310)
"""


from pyspark import SparkContext, SparkConf
from pyspark.sql import *
from pyspark.sql import SQLContext
from pyspark.sql import functions 
from pyspark.mllib.recommendation import *
from pyspark.sql.types import IntegerType
from pyspark import SparkContext

conf = SparkConf().setAppName("AudioRecommender").set("spark.driver.memory","2g")
sc = SparkContext(conf=conf)
'''
rawArtistAlias = sc.textFile("./profiledata_06-May-2005/artist_alias.txt")
rawArtistData = sc.textFile("./profiledata_06-May-2005//artist_data.txt")
rawUserArtistData = sc.textFile("./profiledata_06-May-2005/user_artist_data.txt")
'''
rawArtistData = sc.textFile('s3://cshw6/artist_data.txt')
rawArtistAlias= sc.textFile('s3://cshw6/artist_alias.txt')
rawUserArtistData=sc.textFile('s3://cshw6/user_artist_data.txt')

#running on AWS
user_artist_data = rawUserArtistData

# Random select 50% of test data, seed = T on local
#user_artist_data = rawUserArtistData.sample(False, 0.5, True)

def parseID(id_):
    id_split = id_.rsplit('\t')
    if not id_split[0]:
        return []
    else:
        try:
            return [(int(id_split[0]),id_split[1])]
        except:
            return []  
def parseAlias(alias):
    Alias = alias.rsplit('\t')
    if not Alias[0]:
        return []
    else:
        try:
            return [(int(Alias[0]), int(Alias[1]))]
        except:
            return []

artistByID = dict(rawArtistData.flatMap(lambda x:parseID(x)).collect())
artistAlias = rawArtistAlias.flatMap(lambda x: parseAlias(x)).collectAsMap()
def maptoArtist(x):
    try:
        if len(x.split())==3:
            userID, artistID, count = Split(x)
            finalArtistID = artistAliasBroadcast.value.get(artistID)
            if not finalArtistID:
                finalArtistID = artistID
            return Rating(userID, finalArtistID, count)
        else:
            return Rating(None,None,None)
    except:
            pass
            
def Split(line):
    temp_line= line.split();
    return int(temp_line[0]),int(temp_line[1]),int(temp_line[2])
artistAliasBroadcast = sc.broadcast(artistAlias)

RDD = user_artist_data.map(lambda x: maptoArtist(x))
RDD.cache()
model = ALS.trainImplicit(RDD, 10,5, lambda_ = 0.01, alpha = 1.0)
testID = 2093760
recommendations = map(lambda line: artistByID.get(line.product), model.call("recommendProducts", testID, 10))
print ('TOP 10 RECOMMENDATIONS ARE')
for r in recommendations:
    print (r)

